Shotugn Package

This is a small collection of Shotgun Functions that get results, albeit ineffectively.
Check out: https://en.wikipedia.org/wiki/Bogosort for more info on what these kind of algorithms are.